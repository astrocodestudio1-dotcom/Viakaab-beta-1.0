package com.example.viakaab10102

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.viakaab10102.ui.DriverMapActivity
import com.example.viakaab10102.ui.MainContainerActivity
import com.example.viakaab10102.utils.SessionManager

class MainActivity : AppCompatActivity() {

    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sessionManager = SessionManager(this)

        val btnConductor = findViewById<Button>(R.id.btnConductor)
        val btnRepartidor = findViewById<Button>(R.id.btnRepartidor)
        val btnPasajero = findViewById<Button>(R.id.btnPasajero)
        val btnAmbos = findViewById<Button>(R.id.btnAmbos)

        btnConductor.setOnClickListener {
            selectRoleAndProceed("driver", "Conductor")
        }

        btnRepartidor.setOnClickListener {
            selectRoleAndProceed("delivery", "Repartidor")
        }

        btnPasajero.setOnClickListener {
            selectRoleAndProceed("passenger", "Pasajero")
        }

        btnAmbos.setOnClickListener {
            selectRoleAndProceed("both", "Conductor y Repartidor")
        }
    }

    private fun selectRoleAndProceed(roleKey: String, roleName: String) {
        sessionManager.setSelectedRole(roleKey)

        val currentEmail = sessionManager.getUserEmail()
        val currentName = sessionManager.getUserName()
        val currentToken = sessionManager.getAccessToken()
        sessionManager.createLoginSession(currentEmail, currentName, roleKey, currentToken)

        Toast.makeText(this, "¡Rol seleccionado: $roleName!", Toast.LENGTH_SHORT).show()

        val intent = if (roleKey == "driver" || roleKey == "delivery" || roleKey == "both") {
            Intent(this, DriverMapActivity::class.java)
        } else {
            Intent(this, MainContainerActivity::class.java)
        }
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
