package com.example.viakaab10102;

import android.app.Application;

public class ViaKaabApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
