package com.example.viakaab10102.network;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GeminiClient {

    private static final String GEMINI_API_KEY = "AQ.Ab8RN6Lw2iT3rS224c4K8mA3Gl4hMzBuApGupJt8IbIOY3lbmQ";
    private static final String GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + GEMINI_API_KEY;

    private static final OkHttpClient client = new OkHttpClient();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public interface GeminiCallback {
        void onSuccess(String aiResponse);
        void onError(String errorMessage);
    }

    public static void askGemini(String prompt, GeminiCallback callback) {
        Handler mainHandler = new Handler(Looper.getMainLooper());
        try {
            JSONObject part = new JSONObject();
            part.put("text", "Eres el asistente virtual inteligente de la app de movilidad 'Viakaab' en Felipe Carrillo Puerto, Quintana Roo. Ayuda al usuario amablemente en español con sus dudas sobre viajes, tarifas, envíos y recomendaciones: " + prompt);

            JSONArray partsArray = new JSONArray();
            partsArray.put(part);

            JSONObject content = new JSONObject();
            content.put("parts", partsArray);

            JSONArray contentsArray = new JSONArray();
            contentsArray.put(content);

            JSONObject requestBodyJson = new JSONObject();
            requestBodyJson.put("contents", contentsArray);

            RequestBody body = RequestBody.create(requestBodyJson.toString(), JSON);
            Request request = new Request.Builder()
                    .url(GEMINI_URL)
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    mainHandler.post(() -> callback.onError("Error de conexión con Gemini AI: " + e.getLocalizedMessage()));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    try {
                        JSONObject json = new JSONObject(responseBody);
                        JSONArray candidates = json.optJSONArray("candidates");
                        if (candidates != null && candidates.length() > 0) {
                            JSONObject candidate = candidates.getJSONObject(0);
                            JSONObject contentObj = candidate.optJSONObject("content");
                            if (contentObj != null) {
                                JSONArray parts = contentObj.optJSONArray("parts");
                                if (parts != null && parts.length() > 0) {
                                    String text = parts.getJSONObject(0).optString("text", "No se pudo obtener respuesta.");
                                    mainHandler.post(() -> callback.onSuccess(text.trim()));
                                    return;
                                }
                            }
                        }
                        mainHandler.post(() -> callback.onError("Respuesta vacía de Gemini AI."));
                    } catch (Exception e) {
                        mainHandler.post(() -> callback.onError("Error al procesar respuesta: " + e.getLocalizedMessage()));
                    }
                }
            });
        } catch (Exception e) {
            callback.onError("Error al preparar petición a Gemini: " + e.getLocalizedMessage());
        }
    }
}
