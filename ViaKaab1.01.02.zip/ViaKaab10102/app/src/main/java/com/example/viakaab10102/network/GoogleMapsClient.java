package com.example.viakaab10102.network;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class GoogleMapsClient {

    // API Key oficial de Google Maps
    private static final String MAPS_API_KEY = "AIzaSyAOVYRIgupAurZup5y1PRh8Ismb1A3lLao";
    private static final OkHttpClient client = new OkHttpClient();

    public interface GeocodeCallback {
        void onSuccess(double lat, double lng, String formattedAddress);
        void onError(String errorMessage);
    }

    /**
     * Geocodifica una dirección o nombre de lugar utilizando la API oficial de Google Maps Web Services.
     */
    public static void geocodeAddress(String addressQuery, GeocodeCallback callback) {
        Handler mainHandler = new Handler(Looper.getMainLooper());
        try {
            String encodedQuery = URLEncoder.encode(addressQuery + ", Quintana Roo, México", "UTF-8");
            String url = "https://maps.googleapis.com/maps/api/geocode/json?address=" + encodedQuery + "&key=" + MAPS_API_KEY;

            Request request = new Request.Builder().url(url).build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    mainHandler.post(() -> callback.onError("Error de conexión con Google Maps: " + e.getLocalizedMessage()));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    try {
                        JSONObject json = new JSONObject(responseBody);
                        JSONArray results = json.optJSONArray("results");
                        if (results != null && results.length() > 0) {
                            JSONObject result = results.getJSONObject(0);
                            String formattedAddress = result.optString("formatted_address", addressQuery);
                            JSONObject location = result.getJSONObject("geometry").getJSONObject("location");
                            double lat = location.getDouble("lat");
                            double lng = location.getDouble("lng");

                            mainHandler.post(() -> callback.onSuccess(lat, lng, formattedAddress));
                        } else {
                            mainHandler.post(() -> callback.onError("No se encontraron resultados en Google Maps"));
                        }
                    } catch (Exception e) {
                        mainHandler.post(() -> callback.onError("Error al interpretar respuesta de Google Maps: " + e.getLocalizedMessage()));
                    }
                }
            });
        } catch (Exception e) {
            callback.onError("Error al preparar la consulta de Google Maps: " + e.getLocalizedMessage());
        }
    }

    /**
     * Geocodificación inversa oficial de Google Maps (de Coordenadas GPS lat/lng a Dirección Oficial).
     */
    public static void reverseGeocode(double lat, double lng, GeocodeCallback callback) {
        Handler mainHandler = new Handler(Looper.getMainLooper());
        String url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + lng + "&key=" + MAPS_API_KEY;

        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Error de conexión con Google Maps"));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseBody = response.body() != null ? response.body().string() : "";
                try {
                    JSONObject json = new JSONObject(responseBody);
                    JSONArray results = json.optJSONArray("results");
                    if (results != null && results.length() > 0) {
                        JSONObject result = results.getJSONObject(0);
                        String formattedAddress = result.optString("formatted_address", "Ubicación GPS");
                        mainHandler.post(() -> callback.onSuccess(lat, lng, formattedAddress));
                    } else {
                        mainHandler.post(() -> callback.onError("Ubicación en Google Maps"));
                    }
                } catch (Exception e) {
                    mainHandler.post(() -> callback.onError("Error de geocodificación inversa"));
                }
            }
        });
    }
}
