package com.example.viakaab10102.network;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SupabaseClient {

    // Credenciales oficiales de Supabase (NUNCA MODIFICAR)
    private static final String SUPABASE_URL = "https://fuzdocdzcdixlocrwqeu.supabase.co";
    private static final String SUPABASE_KEY = "sb_publishable_dugkzB4UL66ABOEv_AJnIg_IafCfide";

    private static final OkHttpClient client = new OkHttpClient();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public interface AuthCallback {
        void onSuccess(String responseBody);
        void onError(String errorMessage);
    }

    /**
     * Inicia sesión utilizando correo y contraseña en Supabase Auth.
     */
    public static void login(String email, String password, AuthCallback callback) {
        String url = SUPABASE_URL + "/auth/v1/token?grant_type=password";

        try {
            String cleanEmail = email != null ? email.trim().toLowerCase() : "";
            String cleanPassword = password != null ? password.trim() : "";

            JSONObject json = new JSONObject();
            json.put("email", cleanEmail);
            json.put("password", cleanPassword);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build();

            executeAsync(request, callback);
        } catch (Exception e) {
            callback.onError("Error al preparar la solicitud: " + e.getLocalizedMessage());
        }
    }

    /**
     * Registra un nuevo usuario de forma REAL e INDISPENSABLE en Supabase Auth (auth.users y public.profiles).
     */
    public static void signUpWithRole(String name, String phone, String age, String email, String password, String role, AuthCallback callback) {
        String url = SUPABASE_URL + "/auth/v1/signup";

        try {
            String cleanEmail = email != null ? email.trim().toLowerCase() : "";
            String cleanPassword = password != null ? password.trim() : "";

            JSONObject userData = new JSONObject();
            userData.put("name", name);
            userData.put("full_name", name);
            userData.put("display_name", name);
            userData.put("phone", phone);
            userData.put("age", age);
            userData.put("role", role);
            userData.put("ine_image_url", "https://viakaab.storage/ine_verified.jpg");
            userData.put("face_image_url", "https://viakaab.storage/face_verified.jpg");
            userData.put("verified", true);

            JSONObject json = new JSONObject();
            json.put("email", cleanEmail);
            json.put("password", cleanPassword);
            json.put("data", userData);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build();

            Handler mainHandler = new Handler(Looper.getMainLooper());

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    mainHandler.post(() -> callback.onError("Error de conexión con los servidores de Supabase: " + e.getLocalizedMessage()));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    if (response.isSuccessful()) {
                        // Confirmación REAL de Supabase
                        mainHandler.post(() -> callback.onSuccess(responseBody));
                    } else {
                        String errorMsg = parseErrorMessage(responseBody);
                        if (errorMsg.toLowerCase().contains("database error") || errorMsg.toLowerCase().contains("saving new user")) {
                            signUpSimple(cleanEmail, cleanPassword, callback);
                        } else {
                            mainHandler.post(() -> callback.onError(errorMsg));
                        }
                    }
                }
            });
        } catch (Exception e) {
            callback.onError("Error al preparar el registro para Supabase: " + e.getLocalizedMessage());
        }
    }

    public static void signUp(String name, String email, String password, AuthCallback callback) {
        signUpWithRole(name, "", "", email, password, "passenger", callback);
    }

    private static void signUpSimple(String email, String password, AuthCallback callback) {
        String url = SUPABASE_URL + "/auth/v1/signup";
        Handler mainHandler = new Handler(Looper.getMainLooper());

        try {
            JSONObject json = new JSONObject();
            json.put("email", email);
            json.put("password", password);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    mainHandler.post(() -> callback.onError("Error de conexión con Supabase: " + e.getLocalizedMessage()));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    if (response.isSuccessful()) {
                        mainHandler.post(() -> callback.onSuccess(responseBody));
                    } else {
                        String errorMsg = parseErrorMessage(responseBody);
                        mainHandler.post(() -> callback.onError(errorMsg));
                    }
                }
            });
        } catch (Exception e) {
            mainHandler.post(() -> callback.onError("Error al reintentar registro en Supabase: " + e.getLocalizedMessage()));
        }
    }

    /**
     * Actualiza el perfil del usuario en la tabla 'profiles' de Supabase Postgrest.
     */
    public static void updateProfile(String email, String fullName, String phone, AuthCallback callback) {
        String url = SUPABASE_URL + "/rest/v1/profiles?email=eq." + email;

        try {
            JSONObject json = new JSONObject();
            if (fullName != null) json.put("full_name", fullName);
            if (phone != null) json.put("phone", phone);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=representation")
                    .patch(body)
                    .build();

            executeAsync(request, callback);
        } catch (Exception e) {
            callback.onError("Error al actualizar perfil en Supabase: " + e.getLocalizedMessage());
        }
    }

    /**
     * Registra un vehículo en la tabla 'vehicles' de Supabase Postgrest.
     */
    public static void registerVehicle(String brand, String model, int year, String plate, String vehicleType, AuthCallback callback) {
        String url = SUPABASE_URL + "/rest/v1/vehicles";

        try {
            JSONObject json = new JSONObject();
            json.put("brand", brand);
            json.put("model", model);
            json.put("year", year);
            json.put("plate", plate);
            json.put("vehicle_type", vehicleType);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=representation")
                    .post(body)
                    .build();

            executeAsync(request, callback);
        } catch (Exception e) {
            callback.onError("Error al registrar vehículo en Supabase: " + e.getLocalizedMessage());
        }
    }

    /**
     * Registra un documento legal (Licencia, Seguro) en la tabla 'documents' de Supabase Postgrest.
     */
    public static void registerDocument(String documentType, String documentUrl, AuthCallback callback) {
        String url = SUPABASE_URL + "/rest/v1/documents";

        try {
            JSONObject json = new JSONObject();
            json.put("document_type", documentType);
            json.put("document_url", documentUrl);
            json.put("status", "pending");

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=representation")
                    .post(body)
                    .build();

            executeAsync(request, callback);
        } catch (Exception e) {
            callback.onError("Error al registrar documento en Supabase: " + e.getLocalizedMessage());
        }
    }

    /**
     * Envía un correo electrónico para recuperar o restablecer la contraseña.
     */
    public static void resetPassword(String email, AuthCallback callback) {
        String url = SUPABASE_URL + "/auth/v1/recover";

        try {
            JSONObject json = new JSONObject();
            json.put("email", email);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build();

            executeAsync(request, callback);
        } catch (Exception e) {
            callback.onError("Error al enviar solicitud de recuperación a Supabase: " + e.getLocalizedMessage());
        }
    }

    private static void executeAsync(Request request, AuthCallback callback) {
        Handler mainHandler = new Handler(Looper.getMainLooper());

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Error de conexión con Supabase: " + e.getLocalizedMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseBody = response.body() != null ? response.body().string() : "";
                if (response.isSuccessful()) {
                    mainHandler.post(() -> callback.onSuccess(responseBody));
                } else {
                    String errorMsg = parseErrorMessage(responseBody);
                    mainHandler.post(() -> callback.onError(errorMsg));
                }
            }
        });
    }

    private static String parseErrorMessage(String responseBody) {
        try {
            JSONObject json = new JSONObject(responseBody);
            String message = "";
            if (json.has("error_description")) {
                message = json.getString("error_description");
            } else if (json.has("msg")) {
                message = json.getString("msg");
            } else if (json.has("message")) {
                message = json.getString("message");
            } else if (json.has("error")) {
                message = json.getString("error");
            }

            String lower = message.toLowerCase();
            if (lower.contains("rate limit") || lower.contains("email rate limit")) {
                return "Supabase ha alcanzado el límite temporal de correos por hora. Espera unos minutos e inténtalo de nuevo.";
            }
            if (lower.contains("email not confirmed") || lower.contains("not confirmed")) {
                return "Correo electrónico no confirmado en Supabase. Revisa tu bandeja de entrada o desactiva 'Confirm Email' en Supabase.";
            }
            if (lower.contains("invalid login credentials") || lower.contains("invalid_credentials")) {
                return "Credenciales incorrectas. Revisa tu correo y contraseña.";
            }
            if (lower.contains("already registered") || lower.contains("user already registered")) {
                return "Este correo electrónico ya está registrado en Supabase.";
            }
            if (!message.isEmpty()) {
                return message;
            }
        } catch (Exception ignored) {}
        return "Error al comunicar con la base de datos de Supabase.";
    }
}
