package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;
import com.example.viakaab10102.utils.SessionManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

public class AccountFragment extends Fragment {

    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account, container, false);

        sessionManager = new SessionManager(requireContext());

        TextView tvAccountUserName = view.findViewById(R.id.tvAccountUserName);
        TextView tvAccountUserRating = view.findViewById(R.id.tvAccountUserRating);
        TextView tvAccountInitials = view.findViewById(R.id.tvAccountInitials);

        CardView cardAccountHelp = view.findViewById(R.id.cardAccountHelp);
        CardView cardAccountWallet = view.findViewById(R.id.cardAccountWallet);
        CardView cardAccountSafety = view.findViewById(R.id.cardAccountSafety);
        CardView cardAccountGeminiAI = view.findViewById(R.id.cardAccountGeminiAI);
        CardView cardAccountDriverPanel = view.findViewById(R.id.cardAccountDriverPanel);
        TextView tvAccountLogout = view.findViewById(R.id.tvAccountLogout);

        // Cargar datos del usuario
        String name = sessionManager.getUserName();
        String email = sessionManager.getUserEmail();
        if (name == null || name.isEmpty()) {
            if (!email.isEmpty() && email.contains("@")) {
                String prefix = email.substring(0, email.indexOf("@"));
                name = prefix.substring(0, 1).toUpperCase() + prefix.substring(1);
            } else {
                name = "Usuario ViaKaab";
            }
        }

        tvAccountUserName.setText(name);
        tvAccountUserRating.setText("★ 5.0");

        String initials = "VK";
        if (name.length() >= 2) {
            initials = name.substring(0, 2).toUpperCase();
        }
        tvAccountInitials.setText(initials);

        // Control de visibilidad del Panel de Conductor/Repartidor
        String roleKey = sessionManager.getUserRole();
        if ("driver".equals(roleKey) || "delivery".equals(roleKey) || "both".equals(roleKey)) {
            cardAccountDriverPanel.setVisibility(View.VISIBLE);
        } else {
            cardAccountDriverPanel.setVisibility(View.GONE);
        }

        // Acciones
        cardAccountHelp.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), SupportActivity.class);
            startActivity(intent);
        });

        cardAccountWallet.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), PaymentMethodsActivity.class);
            startActivity(intent);
        });

        cardAccountSafety.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), TermsActivity.class);
            startActivity(intent);
        });

        cardAccountGeminiAI.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), GeminiChatActivity.class);
            startActivity(intent);
        });

        cardAccountDriverPanel.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), DriverProfileActivity.class);
            startActivity(intent);
        });

        tvAccountLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Cerrar sesión")
                    .setMessage("¿Estás seguro de que deseas salir?")
                    .setPositiveButton("Sí, salir", (dialog, which) -> {
                        sessionManager.logout();
                        Intent intent = new Intent(requireContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        requireActivity().finish();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        return view;
    }
}
