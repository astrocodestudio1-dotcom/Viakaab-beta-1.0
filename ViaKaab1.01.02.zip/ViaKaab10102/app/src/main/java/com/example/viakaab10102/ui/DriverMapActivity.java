package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;
import com.example.viakaab10102.utils.SessionManager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class DriverMapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_map);

        sessionManager = new SessionManager(this);

        ImageButton btnDriverMenu = findViewById(R.id.btnDriverMenu);
        SwitchMaterial switchOnlineStatus = findViewById(R.id.switchOnlineStatus);
        TextView tvDriverPanelHeader = findViewById(R.id.tvDriverPanelHeader);

        Button btnAcceptTrip = findViewById(R.id.btnAcceptTrip);
        Button btnCounterOffer = findViewById(R.id.btnCounterOffer);

        // Personalizar según el rol (Conductor, Repartidor o Ambos)
        String role = sessionManager.getUserRole();
        if ("delivery".equals(role)) {
            tvDriverPanelHeader.setText("Solicitudes de entregas/envíos en Felipe Carrillo Puerto");
        } else if ("both".equals(role)) {
            tvDriverPanelHeader.setText("Viajes y entregas disponibles en Felipe Carrillo Puerto");
        }

        // Inicializar mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.driverMap);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Menú Conductor -> Abre el perfil de conductor y registro de vehículo
        btnDriverMenu.setOnClickListener(v -> {
            Intent intent = new Intent(DriverMapActivity.this, DriverProfileActivity.class);
            startActivity(intent);
        });

        // Estado Conectado / Desconectado
        switchOnlineStatus.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                switchOnlineStatus.setText("Conectado");
                Toast.makeText(this, "Estás en línea recibiendo solicitudes cerca de ti", Toast.LENGTH_SHORT).show();
            } else {
                switchOnlineStatus.setText("Desconectado");
                Toast.makeText(this, "Modo fuera de servicio", Toast.LENGTH_SHORT).show();
            }
        });

        // Aceptar Viaje
        btnAcceptTrip.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("¡Viaje Aceptado!")
                    .setMessage("Has aceptado el viaje: Centro ➔ TecNM por $45 MXN.\nDirígete a la ubicación de salida del pasajero.")
                    .setPositiveButton("Iniciar Ruta", (dialog, which) -> 
                        Toast.makeText(DriverMapActivity.this, "Ruta iniciada hacia el pasajero...", Toast.LENGTH_SHORT).show()
                    )
                    .show();
        });

        // Contraofertar Tarifa (Estilo inDrive)
        btnCounterOffer.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Contraofertar Tarifa");
            builder.setMessage("Ingresa tu contraoferta en $ MXN para el pasajero:");

            final EditText inputCounter = new EditText(this);
            inputCounter.setHint("Monto oferta (ej. $50)");
            inputCounter.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            inputCounter.setTextColor(android.graphics.Color.BLACK);
            builder.setView(inputCounter);

            builder.setPositiveButton("Enviar Oferta", (dialog, which) -> {
                String amount = inputCounter.getText().toString().trim();
                if (!amount.isEmpty()) {
                    Toast.makeText(DriverMapActivity.this, "Contraoferta de $" + amount + " MXN enviada al pasajero", Toast.LENGTH_LONG).show();
                }
            });
            builder.setNegativeButton("Cancelar", null);
            builder.show();
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        LatLng carrilloPuerto = new LatLng(19.5775, -88.0453);
        LatLng tripStart = new LatLng(19.5780, -88.0460);
        LatLng tripEnd = new LatLng(19.5850, -88.0410);

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(carrilloPuerto, 14.5f));

        // Solicitud en vivo de un pasajero
        mMap.addMarker(new MarkerOptions()
                .position(tripStart)
                .title("Salida: Centro")
                .snippet("Pasajero esperando viaje ($45 MXN)")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));

        mMap.addMarker(new MarkerOptions()
                .position(tripEnd)
                .title("Destino: TecNM Carrillo Puerto")
                .snippet("Punto final del viaje")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
    }
}
