package com.example.viakaab10102.ui;

import com.example.viakaab10102.MainActivity;
import com.example.viakaab10102.R;
import com.example.viakaab10102.network.SupabaseClient;
import com.example.viakaab10102.utils.SessionManager;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DriverProfileActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private TextView tvDriverName, tvDriverEmail, tvDriverRole, tvDriverIneStatus, tvLicenseStatus, tvInsuranceStatus;
    private EditText etBrand, etModel, etYear, etPlate, etVehicleType;

    private final ActivityResultLauncher<String> inePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    tvDriverIneStatus.setText("Estado INE: Subida y en revisión ✓");
                    tvDriverIneStatus.setTextColor(Color.parseColor("#10B981"));
                    Toast.makeText(this, "Subiendo INE a Supabase...", Toast.LENGTH_SHORT).show();

                    SupabaseClient.registerDocument("ine", uri.toString(), new SupabaseClient.AuthCallback() {
                        @Override
                        public void onSuccess(String responseBody) {
                            Toast.makeText(DriverProfileActivity.this, "¡INE registrada en Supabase!", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onError(String errorMessage) {
                            Toast.makeText(DriverProfileActivity.this, "Error al guardar INE: " + errorMessage, Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
    );

    private final ActivityResultLauncher<String> licensePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    tvLicenseStatus.setText("Estado Licencia: Subida y en revisión ✓");
                    tvLicenseStatus.setTextColor(Color.parseColor("#10B981"));
                    Toast.makeText(this, "Subiendo licencia a Supabase...", Toast.LENGTH_SHORT).show();

                    SupabaseClient.registerDocument("license", uri.toString(), new SupabaseClient.AuthCallback() {
                        @Override
                        public void onSuccess(String responseBody) {
                            Toast.makeText(DriverProfileActivity.this, "¡Licencia registrada en Supabase!", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onError(String errorMessage) {
                            Toast.makeText(DriverProfileActivity.this, "Error al guardar licencia: " + errorMessage, Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
    );

    private final ActivityResultLauncher<String> insurancePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    tvInsuranceStatus.setText("Estado Seguro: Póliza adjuntada ✓");
                    tvInsuranceStatus.setTextColor(Color.parseColor("#10B981"));
                    Toast.makeText(this, "Subiendo póliza de seguro a Supabase...", Toast.LENGTH_SHORT).show();

                    SupabaseClient.registerDocument("insurance", uri.toString(), new SupabaseClient.AuthCallback() {
                        @Override
                        public void onSuccess(String responseBody) {
                            Toast.makeText(DriverProfileActivity.this, "¡Póliza de seguro registrada en Supabase!", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onError(String errorMessage) {
                            Toast.makeText(DriverProfileActivity.this, "Error al guardar seguro: " + errorMessage, Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_profile);

        sessionManager = new SessionManager(this);

        tvDriverName = findViewById(R.id.tvDriverName);
        tvDriverEmail = findViewById(R.id.tvDriverEmail);
        tvDriverRole = findViewById(R.id.tvDriverRole);

        etBrand = findViewById(R.id.etBrand);
        etModel = findViewById(R.id.etModel);
        etYear = findViewById(R.id.etYear);
        etPlate = findViewById(R.id.etPlate);
        etVehicleType = findViewById(R.id.etVehicleType);

        Button btnEditPersonalProfile = findViewById(R.id.btnEditPersonalProfile);
        Button btnSaveVehicle = findViewById(R.id.btnSaveVehicle);

        Button btnUploadDriverIne = findViewById(R.id.btnUploadDriverIne);
        tvDriverIneStatus = findViewById(R.id.tvDriverIneStatus);

        Button btnUploadLicense = findViewById(R.id.btnUploadLicense);
        tvLicenseStatus = findViewById(R.id.tvLicenseStatus);

        Button btnUploadInsurance = findViewById(R.id.btnUploadInsurance);
        tvInsuranceStatus = findViewById(R.id.tvInsuranceStatus);

        TextView tvDriverSupport = findViewById(R.id.tvDriverSupport);
        TextView tvDriverLogout = findViewById(R.id.tvDriverLogout);

        loadUserData();

        btnEditPersonalProfile.setOnClickListener(v -> {
            Intent intent = new Intent(DriverProfileActivity.this, EditProfileActivity.class);
            startActivity(intent);
        });

        tvDriverSupport.setOnClickListener(v -> {
            Intent intent = new Intent(DriverProfileActivity.this, SupportActivity.class);
            startActivity(intent);
        });

        btnUploadDriverIne.setOnClickListener(v -> inePickerLauncher.launch("image/*"));
        btnUploadLicense.setOnClickListener(v -> licensePickerLauncher.launch("image/*"));
        btnUploadInsurance.setOnClickListener(v -> insurancePickerLauncher.launch("image/*"));

        btnSaveVehicle.setOnClickListener(v -> {
            String brand = etBrand.getText() != null ? etBrand.getText().toString().trim() : "";
            String model = etModel.getText() != null ? etModel.getText().toString().trim() : "";
            String yearStr = etYear.getText() != null ? etYear.getText().toString().trim() : "";
            String plate = etPlate.getText() != null ? etPlate.getText().toString().trim() : "";
            String vehicleType = etVehicleType.getText() != null ? etVehicleType.getText().toString().trim() : "";

            if (brand.isEmpty() || model.isEmpty() || yearStr.isEmpty() || plate.isEmpty() || vehicleType.isEmpty()) {
                Toast.makeText(this, "Por favor completa todos los datos del vehículo", Toast.LENGTH_SHORT).show();
                return;
            }

            int year;
            try {
                year = Integer.parseInt(yearStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Ingresa un año válido", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Guardando vehículo en Supabase...", Toast.LENGTH_SHORT).show();

            SupabaseClient.registerVehicle(brand, model, year, plate, vehicleType, new SupabaseClient.AuthCallback() {
                @Override
                public void onSuccess(String responseBody) {
                    Toast.makeText(DriverProfileActivity.this, "¡Vehículo registrado con éxito en Supabase!", Toast.LENGTH_LONG).show();
                }

                @Override
                public void onError(String errorMessage) {
                    Toast.makeText(DriverProfileActivity.this, "Error al registrar vehículo: " + errorMessage, Toast.LENGTH_LONG).show();
                }
            });
        });

        tvDriverLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Cerrar sesión")
                    .setMessage("¿Estás seguro de que deseas salir?")
                    .setPositiveButton("Sí, salir", (dialog, which) -> {
                        sessionManager.logout();
                        Intent intent = new Intent(DriverProfileActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserData();
    }

    private void loadUserData() {
        String email = sessionManager.getUserEmail();
        String name = sessionManager.getUserName();
        String roleKey = sessionManager.getUserRole();

        if (name == null || name.isEmpty()) {
            if (!email.isEmpty() && email.contains("@")) {
                String prefix = email.substring(0, email.indexOf("@"));
                name = prefix.substring(0, 1).toUpperCase() + prefix.substring(1);
            } else {
                name = "Conductor ViaKaab";
            }
        }

        String roleDisplay = "Conductor";
        if ("delivery".equals(roleKey)) {
            roleDisplay = "Repartidor";
        } else if ("both".equals(roleKey)) {
            roleDisplay = "Conductor y Repartidor";
        }

        tvDriverName.setText("Nombre: " + name);
        tvDriverEmail.setText("Correo: " + (email.isEmpty() ? "No disponible" : email));
        tvDriverRole.setText("Modo: " + roleDisplay + " · ★ 4.9");
    }
}
