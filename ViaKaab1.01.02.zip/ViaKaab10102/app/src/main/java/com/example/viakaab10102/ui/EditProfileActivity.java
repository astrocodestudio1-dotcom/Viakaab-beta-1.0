package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;
import com.example.viakaab10102.network.SupabaseClient;
import com.example.viakaab10102.utils.SessionManager;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private ImageView ivProfileImage;
    private TextView tvProfileInitials;
    private EditText etEditName, etEditPhone;
    private String selectedImageUri = "";

    private final ActivityResultLauncher<String> mGetContent = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    selectedImageUri = uri.toString();
                    ivProfileImage.setImageURI(uri);
                    tvProfileInitials.setText(""); // Ocultar iniciales si hay imagen
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        sessionManager = new SessionManager(this);

        ivProfileImage = findViewById(R.id.ivProfileImage);
        tvProfileInitials = findViewById(R.id.tvProfileInitials);
        TextView tvChangePhoto = findViewById(R.id.tvChangePhoto);
        etEditName = findViewById(R.id.etEditName);
        etEditPhone = findViewById(R.id.etEditPhone);
        Button btnSaveProfile = findViewById(R.id.btnSaveProfile);

        // Cargar datos actuales
        String currentName = sessionManager.getUserName();
        String currentPhone = sessionManager.getUserPhone();
        selectedImageUri = sessionManager.getProfileImageUri();

        if (currentName != null && !currentName.isEmpty()) {
            etEditName.setText(currentName);
            if (currentName.length() >= 2) {
                tvProfileInitials.setText(currentName.substring(0, 2).toUpperCase());
            }
        }
        if (currentPhone != null && !currentPhone.isEmpty()) {
            etEditPhone.setText(currentPhone);
        }
        if (selectedImageUri != null && !selectedImageUri.isEmpty()) {
            try {
                ivProfileImage.setImageURI(Uri.parse(selectedImageUri));
                tvProfileInitials.setText("");
            } catch (Exception ignored) {}
        }

        // Seleccionar foto de galería
        tvChangePhoto.setOnClickListener(v -> mGetContent.launch("image/*"));
        ivProfileImage.setOnClickListener(v -> mGetContent.launch("image/*"));

        // Guardar cambios en Supabase y sesión
        btnSaveProfile.setOnClickListener(v -> {
            String name = etEditName.getText() != null ? etEditName.getText().toString().trim() : "";
            String phone = etEditPhone.getText() != null ? etEditPhone.getText().toString().trim() : "";
            String email = sessionManager.getUserEmail();

            if (name.isEmpty()) {
                etEditName.setError("El nombre no puede estar vacío");
                return;
            }

            Toast.makeText(this, "Actualizando perfil en Supabase...", Toast.LENGTH_SHORT).show();

            SupabaseClient.updateProfile(email, name, phone, new SupabaseClient.AuthCallback() {
                @Override
                public void onSuccess(String responseBody) {
                    sessionManager.setUserName(name);
                    sessionManager.setUserPhone(phone);
                    sessionManager.setProfileImageUri(selectedImageUri);

                    Toast.makeText(EditProfileActivity.this, "¡Perfil actualizado en base de datos!", Toast.LENGTH_SHORT).show();
                    finish();
                }

                @Override
                public void onError(String errorMessage) {
                    Toast.makeText(EditProfileActivity.this, "Error al actualizar perfil: " + errorMessage, Toast.LENGTH_LONG).show();
                }
            });
        });
    }
}
