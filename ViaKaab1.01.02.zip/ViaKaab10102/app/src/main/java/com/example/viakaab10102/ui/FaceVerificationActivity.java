package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

public class FaceVerificationActivity extends AppCompatActivity {

    private static final int CAMERA_PERMISSION_CODE = 100;
    private PreviewView viewFinder;
    private ImageCapture imageCapture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_verification);

        viewFinder = findViewById(R.id.viewFinder);
        Button btnCaptureFace = findViewById(R.id.btnCaptureFace);
        TextView tvInstructionStep = findViewById(R.id.tvInstructionStep);

        // Mostrar diálogo tutorial inicial antes de abrir la cámara
        showTutorialDialog();

        // Solicitar permisos de cámara
        if (allPermissionsGranted()) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        }

        btnCaptureFace.setOnClickListener(v -> {
            tvInstructionStep.setText("Analizando liveness y biometría facial...");
            btnCaptureFace.setEnabled(false);

            // Simular procesamiento de IA facial y confirmar verificación
            viewFinder.postDelayed(() -> {
                Toast.makeText(this, "¡Rostro verificado exitosamente para Felipe Carrillo Puerto!", Toast.LENGTH_LONG).show();
                setResult(RESULT_OK);
                finish();
            }, 1800);
        });
    }

    private void showTutorialDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Instrucciones de Verificación Facial")
                .setMessage("Para garantizar la seguridad en ViaKaab (Felipe Carrillo Puerto):\n\n" +
                        "1. Sostén tu teléfono frente a tu rostro.\n" +
                        "2. Centra tu cara dentro del óvalo verde.\n" +
                        "3. Evita usar lentes de sol o gorras.\n" +
                        "4. Mantén una iluminación adecuada y presiona 'Capturar'.")
                .setPositiveButton("¡Entendido!", (dialog, which) -> dialog.dismiss())
                .setCancelable(false)
                .show();
    }

    private boolean allPermissionsGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (allPermissionsGranted()) {
                startCamera();
            } else {
                Toast.makeText(this, "Se requiere permiso de cámara para el reconocimiento facial.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(viewFinder.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder().build();

                // Usar cámara frontal para reconocimiento facial (Selfie)
                CameraSelector cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA;

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture);

            } catch (Exception e) {
                Toast.makeText(this, "Error al iniciar la cámara: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }
}
