package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;
import com.example.viakaab10102.network.GeminiClient;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GeminiChatActivity extends AppCompatActivity {

    private TextView tvChatLog;
    private EditText etUserPrompt;
    private ScrollView scrollViewChat;
    private StringBuilder chatHistory = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gemini_chat);

        tvChatLog = findViewById(R.id.tvChatLog);
        etUserPrompt = findViewById(R.id.etUserPrompt);
        Button btnSendPrompt = findViewById(R.id.btnSendPrompt);
        scrollViewChat = findViewById(R.id.scrollViewChat);

        chatHistory.append("¡Hola! Soy tu asistente de Inteligencia Artificial Gemini de ViaKaab. ¿En qué puedo ayudarte hoy con tus viajes o entregas en Felipe Carrillo Puerto?\n\n");

        btnSendPrompt.setOnClickListener(v -> {
            String prompt = etUserPrompt.getText() != null ? etUserPrompt.getText().toString().trim() : "";
            if (prompt.isEmpty()) {
                etUserPrompt.setError("Escribe una pregunta para Gemini");
                return;
            }

            chatHistory.append("👤 Tú: ").append(prompt).append("\n\n");
            tvChatLog.setText(chatHistory.toString());
            etUserPrompt.setText("");
            scrollToBottom();

            Toast.makeText(this, "Gemini está pensando...", Toast.LENGTH_SHORT).show();

            GeminiClient.askGemini(prompt, new GeminiClient.GeminiCallback() {
                @Override
                public void onSuccess(String aiResponse) {
                    chatHistory.append("🤖 Gemini AI: ").append(aiResponse).append("\n\n");
                    tvChatLog.setText(chatHistory.toString());
                    scrollToBottom();
                }

                @Override
                public void onError(String errorMessage) {
                    chatHistory.append("⚠️ Error: ").append(errorMessage).append("\n\n");
                    tvChatLog.setText(chatHistory.toString());
                    scrollToBottom();
                }
            });
        });
    }

    private void scrollToBottom() {
        scrollViewChat.post(() -> scrollViewChat.fullScroll(ScrollView.FOCUS_DOWN));
    }
}
