package com.example.viakaab10102.ui;

import com.example.viakaab10102.MainActivity;
import com.example.viakaab10102.R;
import com.example.viakaab10102.utils.SessionManager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class HomeActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private ImageView ivHomeProfile;
    private TextView tvUserInitials, tvUserName, tvUserRoleAndRating, tvProfileName, tvProfileEmail, tvProfilePhone;
    private CardView cardDriverPanel;
    private TextView tvDriverPanelTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        sessionManager = new SessionManager(this);

        ivHomeProfile = findViewById(R.id.ivHomeProfile);
        tvUserInitials = findViewById(R.id.tvUserInitials);
        tvUserName = findViewById(R.id.tvUserName);
        tvUserRoleAndRating = findViewById(R.id.tvUserRoleAndRating);
        tvProfileName = findViewById(R.id.tvProfileName);
        tvProfileEmail = findViewById(R.id.tvProfileEmail);
        tvProfilePhone = findViewById(R.id.tvProfilePhone);

        cardDriverPanel = findViewById(R.id.cardDriverPanel);
        tvDriverPanelTitle = findViewById(R.id.tvDriverPanelTitle);

        CardView cardMyTrips = findViewById(R.id.cardMyTrips);
        CardView cardEditProfile = findViewById(R.id.cardEditProfile);
        TextView tvPaymentRecords = findViewById(R.id.tvPaymentRecords);
        TextView tvSupport = findViewById(R.id.tvSupport);
        TextView tvLogout = findViewById(R.id.tvLogout);

        // Acciones de las tarjetas y opciones
        cardMyTrips.setOnClickListener(v -> 
            Toast.makeText(this, "Sección de Mis Viajes próximamente", Toast.LENGTH_SHORT).show()
        );

        cardEditProfile.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, EditProfileActivity.class);
            startActivity(intent);
        });

        // Abrir pantalla de Métodos de Pago (Efectivo, Tarjeta, Transferencia SPEI, Crédito)
        tvPaymentRecords.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, PaymentMethodsActivity.class);
            startActivity(intent);
        });

        tvSupport.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, SupportActivity.class);
            startActivity(intent);
        });

        cardDriverPanel.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, DriverProfileActivity.class);
            startActivity(intent);
        });

        // Botón Cerrar Sesión con confirmación
        tvLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Cerrar sesión")
                    .setMessage("¿Estás seguro de que deseas salir de tu cuenta?")
                    .setPositiveButton("Sí, salir", (dialog, which) -> {
                        sessionManager.logout();
                        Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserData();
    }

    private void loadUserData() {
        String email = sessionManager.getUserEmail();
        String name = sessionManager.getUserName();
        String phone = sessionManager.getUserPhone();
        String imageUriStr = sessionManager.getProfileImageUri();
        String roleKey = sessionManager.getUserRole();

        // Si no hay nombre guardado en sesión, generarlo a partir del correo
        if (name == null || name.isEmpty()) {
            if (!email.isEmpty() && email.contains("@")) {
                String prefix = email.substring(0, email.indexOf("@"));
                name = prefix.substring(0, 1).toUpperCase() + prefix.substring(1);
            } else {
                name = "Usuario ViaKaab";
            }
        }

        // Mapear el rol para mostrarlo de forma amigable y controlar el panel de conductor
        String roleDisplay = "Pasajero";
        if ("driver".equals(roleKey)) {
            roleDisplay = "Conductor";
            cardDriverPanel.setVisibility(View.VISIBLE);
            tvDriverPanelTitle.setText("🚗 Panel de Conductor");
        } else if ("delivery".equals(roleKey)) {
            roleDisplay = "Repartidor";
            cardDriverPanel.setVisibility(View.VISIBLE);
            tvDriverPanelTitle.setText("🛵 Panel de Repartidor");
        } else if ("both".equals(roleKey)) {
            roleDisplay = "Conductor y Repartidor";
            cardDriverPanel.setVisibility(View.VISIBLE);
            tvDriverPanelTitle.setText("🚗🛵 Panel de Conductor y Repartidor");
        } else {
            cardDriverPanel.setVisibility(View.GONE);
        }

        // Iniciales para el avatar
        String initials = "VK";
        if (name.length() >= 2) {
            initials = name.substring(0, 2).toUpperCase();
        }

        tvUserInitials.setText(initials);
        tvUserName.setText(name);
        // Calificación inicial en 0.0 (Irá aumentando conforme reciban calificaciones de los viajes en Supabase)
        tvUserRoleAndRating.setText(roleDisplay + " · ★ 0.0");

        tvProfileName.setText("Nombre: " + name);
        tvProfileEmail.setText("Correo: " + (email.isEmpty() ? "No disponible" : email));
        tvProfilePhone.setText("Teléfono: " + (phone.isEmpty() ? "Sin registrar" : phone));

        // Cargar foto de perfil si existe
        if (imageUriStr != null && !imageUriStr.isEmpty()) {
            try {
                ivHomeProfile.setImageURI(Uri.parse(imageUriStr));
                tvUserInitials.setText(""); // Ocultar iniciales
            } catch (Exception e) {
                ivHomeProfile.setImageDrawable(null);
                tvUserInitials.setText(initials);
            }
        } else {
            ivHomeProfile.setImageDrawable(null);
            tvUserInitials.setText(initials);
        }
    }
}
