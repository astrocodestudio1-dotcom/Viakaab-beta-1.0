package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        CardView cardSearchWhereTo = view.findViewById(R.id.cardSearchWhereTo);
        LinearLayout layoutOptionTrip = view.findViewById(R.id.layoutOptionTrip);
        LinearLayout layoutOptionSeniors = view.findViewById(R.id.layoutOptionSeniors);
        LinearLayout layoutOptionRent = view.findViewById(R.id.layoutOptionRent);
        LinearLayout layoutOptionReserve = view.findViewById(R.id.layoutOptionReserve);

        View.OnClickListener openMapListener = v -> {
            Intent intent = new Intent(requireContext(), PassengerMapActivity.class);
            startActivity(intent);
        };

        if (cardSearchWhereTo != null) cardSearchWhereTo.setOnClickListener(openMapListener);
        if (layoutOptionTrip != null) layoutOptionTrip.setOnClickListener(openMapListener);

        if (layoutOptionSeniors != null) {
            layoutOptionSeniors.setOnClickListener(v -> 
                Toast.makeText(requireContext(), "Modo Personas Mayores: Asistencia personalizada en viaje", Toast.LENGTH_SHORT).show()
            );
        }

        if (layoutOptionRent != null) layoutOptionRent.setOnClickListener(openMapListener);

        if (layoutOptionReserve != null) {
            layoutOptionReserve.setOnClickListener(v -> 
                Toast.makeText(requireContext(), "Reserva de Viajes programados próximamente", Toast.LENGTH_SHORT).show()
            );
        }

        return view;
    }
}
