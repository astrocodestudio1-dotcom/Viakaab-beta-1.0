package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

public class IneVerificationActivity extends AppCompatActivity {

    private static final int CAMERA_PERMISSION_CODE = 101;
    private PreviewView viewFinderIne;
    private TextView tvIneInstruction;
    private Button btnCaptureIneSide;

    private int currentStep = 1; // 1 = Frente, 2 = Reverso

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ine_verification);

        viewFinderIne = findViewById(R.id.viewFinderIne);
        tvIneInstruction = findViewById(R.id.tvIneInstruction);
        btnCaptureIneSide = findViewById(R.id.btnCaptureIneSide);

        showTutorialDialog();

        if (allPermissionsGranted()) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        }

        btnCaptureIneSide.setOnClickListener(v -> {
            if (currentStep == 1) {
                // Capturar Frente completado -> Pasar a Reverso
                Toast.makeText(this, "Frente de INE capturado correctamente", Toast.LENGTH_SHORT).show();
                currentStep = 2;
                tvIneInstruction.setText("Paso 2: Coloca la parte TRASERA (reverso) de tu INE dentro del recuadro.");
                btnCaptureIneSide.setText("Capturar Reverso de INE");
            } else {
                // Capturar Reverso completado -> Finalizar verificación de INE
                Toast.makeText(this, "¡INE verificada exitosamente para ViaKaab!", Toast.LENGTH_LONG).show();
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    private void showTutorialDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Verificación de INE")
                .setMessage("Para validar tu identidad en Felipe Carrillo Puerto:\n\n" +
                        "1. Coloca tu INE sobre una superficie plana con buena iluminación.\n" +
                        "2. Alinea el **Frente** de tu INE dentro del rectángulo verde y presiona 'Capturar'.\n" +
                        "3. A continuación, haz lo mismo con el **Reverso** de tu INE.")
                .setPositiveButton("Empezar", (dialog, which) -> dialog.dismiss())
                .setCancelable(false)
                .show();
    }

    private boolean allPermissionsGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (allPermissionsGranted()) {
                startCamera();
            } else {
                Toast.makeText(this, "Se requiere permiso de cámara para escanear tu INE.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(viewFinderIne.getSurfaceProvider());

                ImageCapture imageCapture = new ImageCapture.Builder().build();

                // Usar cámara trasera para fotografiar la INE
                CameraSelector cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA;

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture);

            } catch (Exception e) {
                Toast.makeText(this, "Error al iniciar cámara trasera: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }
}
