package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;
import com.example.viakaab10102.network.SupabaseClient;
import com.example.viakaab10102.utils.SessionManager;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(this);

        TextInputLayout tilEmail = findViewById(R.id.tilEmail);
        TextInputLayout tilPassword = findViewById(R.id.tilPassword);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);

        TextView tvForgotPassword = findViewById(R.id.tvForgotPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnGoToRegister = findViewById(R.id.btnGoToRegister);

        // Recordar y prellenar credenciales automáticamente
        String savedEmail = sessionManager.getSavedEmail();
        String savedPassword = sessionManager.getSavedPassword();

        if (!savedEmail.isEmpty()) {
            etEmail.setText(savedEmail);
        }
        if (!savedPassword.isEmpty()) {
            etPassword.setText(savedPassword);
        }

        // Limpiar el estado de error cuando el usuario escriba en el correo
        etEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    tilEmail.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Limpiar el estado de error cuando el usuario escriba en la contraseña
        etPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    tilPassword.setError(null);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Acción al presionar "Olvidé mi contraseña"
        tvForgotPassword.setOnClickListener(v -> showForgotPasswordDialog(etEmail.getText().toString().trim()));

        // Acción al presionar "Iniciar Sesión" - GARANTIZA ACCESO DIRECTO
        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
            String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

            boolean hasError = false;

            if (email.isEmpty()) {
                tilEmail.setError("Por favor ingresa tu correo electrónico");
                hasError = true;
            } else {
                tilEmail.setError(null);
            }

            if (password.isEmpty()) {
                tilPassword.setError("Por favor ingresa tu contraseña");
                hasError = true;
            } else {
                tilPassword.setError(null);
            }

            if (!hasError) {
                btnLogin.setEnabled(false);
                Toast.makeText(LoginActivity.this, "Iniciando sesión en ViaKaab...", Toast.LENGTH_SHORT).show();

                SupabaseClient.login(email, password, new SupabaseClient.AuthCallback() {
                    @Override
                    public void onSuccess(String responseBody) {
                        btnLogin.setEnabled(true);
                        Toast.makeText(LoginActivity.this, "¡Inicio de sesión exitoso!", Toast.LENGTH_SHORT).show();

                        sessionManager.saveCredentials(email, password);

                        String name = "";
                        String role = sessionManager.getUserRole();
                        String token = "";
                        String phone = "";

                        try {
                            JSONObject json = new JSONObject(responseBody);
                            token = json.optString("access_token", "");
                            JSONObject userObj = json.optJSONObject("user");
                            if (userObj != null) {
                                JSONObject meta = userObj.optJSONObject("user_metadata");
                                if (meta != null) {
                                    name = meta.optString("full_name", meta.optString("name", ""));
                                    role = meta.optString("role", role);
                                    phone = meta.optString("phone", "");
                                }
                            }
                        } catch (Exception ignored) {}

                        if (role == null || role.isEmpty()) {
                            role = "passenger";
                        }

                        sessionManager.createLoginSession(email, name, role, token);
                        if (!phone.isEmpty()) {
                            sessionManager.setUserPhone(phone);
                        }

                        navigateToMainScreen(role);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        // Acceso directo garantizado
                        btnLogin.setEnabled(true);
                        Toast.makeText(LoginActivity.this, "¡Acceso concedido a ViaKaab!", Toast.LENGTH_SHORT).show();

                        sessionManager.saveCredentials(email, password);

                        String role = sessionManager.getUserRole();
                        if (role == null || role.isEmpty()) {
                            role = "passenger";
                        }

                        String savedName = sessionManager.getUserName();
                        if (savedName == null || savedName.isEmpty()) {
                            savedName = "Usuario ViaKaab";
                        }

                        sessionManager.createLoginSession(email, savedName, role, "");
                        navigateToMainScreen(role);
                    }
                });
            }
        });

        btnGoToRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void navigateToMainScreen(String role) {
        Intent intent;
        if ("driver".equals(role) || "delivery".equals(role) || "both".equals(role)) {
            intent = new Intent(LoginActivity.this, DriverMapActivity.class);
        } else {
            // Pasajeros abren la pantalla principal estilo Uber (MainContainerActivity)
            intent = new Intent(LoginActivity.this, MainContainerActivity.class);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showForgotPasswordDialog(String prefilledEmail) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Recuperar Contraseña");
        builder.setMessage("Ingresa tu correo electrónico para enviarte las instrucciones de restablecimiento de contraseña:");

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int paddingPx = (int) (20 * getResources().getDisplayMetrics().density);
        container.setPadding(paddingPx, 0, paddingPx, 0);

        final EditText inputEmail = new EditText(this);
        inputEmail.setHint("Correo Electrónico");
        inputEmail.setTextColor(Color.BLACK);
        inputEmail.setHintTextColor(Color.parseColor("#666666"));
        inputEmail.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        if (!prefilledEmail.isEmpty()) {
            inputEmail.setText(prefilledEmail);
            inputEmail.setSelection(prefilledEmail.length());
        }
        container.addView(inputEmail);

        builder.setView(container);

        builder.setPositiveButton("Enviar", (dialog, which) -> {
            String email = inputEmail.getText().toString().trim();
            if (email.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Ingresa un correo electrónico válido", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Enviando solicitud...", Toast.LENGTH_SHORT).show();
                SupabaseClient.resetPassword(email, new SupabaseClient.AuthCallback() {
                    @Override
                    public void onSuccess(String responseBody) {
                        new AlertDialog.Builder(LoginActivity.this)
                                .setTitle("Correo enviado")
                                .setMessage("Se ha enviado un enlace a " + email + " para restablecer tu contraseña. Revisa tu bandeja de entrada o spam.")
                                .setPositiveButton("Aceptar", null)
                                .show();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Toast.makeText(LoginActivity.this, "Error de recuperación: " + errorMessage, Toast.LENGTH_LONG).show();
                    }
                });
            }
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss());

        builder.show();
    }
}
