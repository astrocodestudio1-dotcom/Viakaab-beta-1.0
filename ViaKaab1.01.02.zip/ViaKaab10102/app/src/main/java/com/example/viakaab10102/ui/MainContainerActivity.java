package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainContainerActivity extends AppCompatActivity {

    private LinearLayout tabHome, tabOptions, tabActivity, tabAccount;
    private TextView tvTabHome, tvTabOptions, tvTabActivity, tvTabAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_container);

        try {
            tabHome = findViewById(R.id.tabHome);
            tabOptions = findViewById(R.id.tabOptions);
            tabActivity = findViewById(R.id.tabActivity);
            tabAccount = findViewById(R.id.tabAccount);

            tvTabHome = findViewById(R.id.tvTabHome);
            tvTabOptions = findViewById(R.id.tvTabOptions);
            tvTabActivity = findViewById(R.id.tvTabActivity);
            tvTabAccount = findViewById(R.id.tvTabAccount);

            if (savedInstanceState == null) {
                loadFragment(new HomeFragment());
                updateTabSelection(0);
            }

            if (tabHome != null) {
                tabHome.setOnClickListener(v -> {
                    loadFragment(new HomeFragment());
                    updateTabSelection(0);
                });
            }

            if (tabOptions != null) {
                tabOptions.setOnClickListener(v -> {
                    loadFragment(new ServicesFragment());
                    updateTabSelection(1);
                });
            }

            if (tabActivity != null) {
                tabActivity.setOnClickListener(v -> {
                    loadFragment(new ActivityFragment());
                    updateTabSelection(2);
                });
            }

            if (tabAccount != null) {
                tabAccount.setOnClickListener(v -> {
                    loadFragment(new AccountFragment());
                    updateTabSelection(3);
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateTabSelection(int index) {
        try {
            if (tvTabHome != null) tvTabHome.setTextColor(index == 0 ? Color.parseColor("#FFFFFF") : Color.parseColor("#94A3B8"));
            if (tvTabOptions != null) tvTabOptions.setTextColor(index == 1 ? Color.parseColor("#FFFFFF") : Color.parseColor("#94A3B8"));
            if (tvTabActivity != null) tvTabActivity.setTextColor(index == 2 ? Color.parseColor("#FFFFFF") : Color.parseColor("#94A3B8"));
            if (tvTabAccount != null) tvTabAccount.setTextColor(index == 3 ? Color.parseColor("#FFFFFF") : Color.parseColor("#94A3B8"));
        } catch (Exception ignored) {}
    }

    private void loadFragment(Fragment fragment) {
        try {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commitAllowingStateLoss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
