package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;
import com.example.viakaab10102.network.GoogleMapsClient;
import com.example.viakaab10102.utils.SessionManager;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.textfield.TextInputLayout;

public class PassengerMapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_CODE = 200;
    private GoogleMap mMap;
    private SessionManager sessionManager;
    private FusedLocationProviderClient fusedLocationClient;

    private EditText etPickupLocation, etDestinationLocation, etSeats, etPackageDetails, etRecipient, etFareOffer;
    private TextInputLayout tilSeats, tilPackageDetails, tilRecipient;
    private Button btnModeStandard, btnModeIntercity, btnModeDelivery, btnRequestTrip;
    private String selectedMode = "Estándar";

    private Marker pickupMarker = null;
    private Marker destinationMarker = null;
    private LatLng userCurrentLatLng = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_map);

        sessionManager = new SessionManager(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        ImageButton btnMenu = findViewById(R.id.btnMenu);
        ImageButton fabMyLocation = findViewById(R.id.fabMyLocation);

        etPickupLocation = findViewById(R.id.etPickupLocation);
        etDestinationLocation = findViewById(R.id.etDestinationLocation);
        etSeats = findViewById(R.id.etSeats);
        etPackageDetails = findViewById(R.id.etPackageDetails);
        etRecipient = findViewById(R.id.etRecipient);
        etFareOffer = findViewById(R.id.etFareOffer);

        tilSeats = findViewById(R.id.tilSeats);
        tilPackageDetails = findViewById(R.id.tilPackageDetails);
        tilRecipient = findViewById(R.id.tilRecipient);

        btnModeStandard = findViewById(R.id.btnModeStandard);
        btnModeIntercity = findViewById(R.id.btnModeIntercity);
        btnModeDelivery = findViewById(R.id.btnModeDelivery);
        btnRequestTrip = findViewById(R.id.btnRequestTrip);

        // Inicializar mapa de Google
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Búsqueda dinámica oficial con Google Maps Web API
        etDestinationLocation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().trim();
                if (query.length() >= 3) {
                    searchDestinationWithGoogleMaps(query);
                } else if (query.isEmpty() && destinationMarker != null) {
                    destinationMarker.remove();
                    destinationMarker = null;
                    if (userCurrentLatLng != null) {
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userCurrentLatLng, 16f));
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Abrir Menú de Perfil
        btnMenu.setOnClickListener(v -> {
            Intent intent = new Intent(PassengerMapActivity.this, HomeActivity.class);
            startActivity(intent);
        });

        // Recentrar mapa en la ubicación GPS real del usuario
        fabMyLocation.setOnClickListener(v -> fetchRealTimeUserLocation());

        // Cambiar entre Modos de Servicio
        btnModeStandard.setOnClickListener(v -> setServiceMode("Estándar"));
        btnModeIntercity.setOnClickListener(v -> setServiceMode("Ciudad a Ciudad"));
        btnModeDelivery.setOnClickListener(v -> setServiceMode("Entregas"));

        // Solicitar Viaje / Envío / Interurbano
        btnRequestTrip.setOnClickListener(v -> {
            String pickup = etPickupLocation.getText() != null ? etPickupLocation.getText().toString().trim() : "";
            String destination = etDestinationLocation.getText() != null ? etDestinationLocation.getText().toString().trim() : "";
            String fare = etFareOffer.getText() != null ? etFareOffer.getText().toString().trim() : "";

            if (pickup.isEmpty()) {
                etPickupLocation.setError("Indica el punto de origen o recolección");
                return;
            }
            if (destination.isEmpty()) {
                etDestinationLocation.setError("Indica el destino o punto de entrega");
                return;
            }
            if (fare.isEmpty()) {
                etFareOffer.setError("Ingresa tu oferta en $ MXN");
                return;
            }

            StringBuilder detailsMsg = new StringBuilder();
            detailsMsg.append("🟢 Origen / Recogida:\n").append(pickup).append("\n\n");
            detailsMsg.append("🔴 Destino / Entrega:\n").append(destination).append("\n\n");

            if ("Ciudad a Ciudad".equals(selectedMode)) {
                String seats = etSeats.getText() != null ? etSeats.getText().toString().trim() : "1";
                detailsMsg.append("👥 Pasajeros/Asientos: ").append(seats.isEmpty() ? "1" : seats).append("\n\n");
            } else if ("Entregas".equals(selectedMode)) {
                String packageInfo = etPackageDetails.getText() != null ? etPackageDetails.getText().toString().trim() : "";
                String recipientInfo = etRecipient.getText() != null ? etRecipient.getText().toString().trim() : "";

                if (!packageInfo.isEmpty()) {
                    detailsMsg.append("📦 Paquete: ").append(packageInfo).append("\n");
                }
                if (!recipientInfo.isEmpty()) {
                    detailsMsg.append("📞 Recibe: ").append(recipientInfo).append("\n\n");
                }
            }

            detailsMsg.append("💵 Tu oferta de tarifa:\n$").append(fare).append(" MXN\n\n¿Deseas enviar esta oferta a los conductores y repartidores?");

            String title = "Entregas".equals(selectedMode) ? "Solicitud de Envío de Paquete" : ("Ciudad a Ciudad".equals(selectedMode) ? "Solicitud de Viaje Interurbano" : "Solicitud de Viaje Local");

            new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(detailsMsg.toString())
                    .setPositiveButton("Publicar Oferta", (dialog, which) -> {
                        Toast.makeText(PassengerMapActivity.this, "¡Oferta enviada a conductores y repartidores cerca de ti!", Toast.LENGTH_LONG).show();
                        etDestinationLocation.setText("");
                        etFareOffer.setText("");
                        etPackageDetails.setText("");
                        etRecipient.setText("");
                        etSeats.setText("");
                        if (destinationMarker != null) {
                            destinationMarker.remove();
                            destinationMarker = null;
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }

    private void setServiceMode(String mode) {
        selectedMode = mode;
        if ("Entregas".equals(mode)) {
            btnModeStandard.setBackgroundColor(Color.parseColor("#1E293B"));
            btnModeIntercity.setBackgroundColor(Color.parseColor("#1E293B"));
            btnModeDelivery.setBackgroundColor(Color.parseColor("#3B82F6"));

            tilSeats.setVisibility(View.GONE);
            tilPackageDetails.setVisibility(View.VISIBLE);
            tilRecipient.setVisibility(View.VISIBLE);

            etPickupLocation.setHint("🟢 Recolección de Paquete (¿Dónde lo recogen?)");
            etDestinationLocation.setHint("🔴 Entrega de Paquete (¿A dónde lo llevan?)");
            btnRequestTrip.setText("Solicitar Envío de Paquete");
            Toast.makeText(this, "Modo: Entrega y Reparto de Paquetes seleccionado", Toast.LENGTH_SHORT).show();
        } else if ("Ciudad a Ciudad".equals(mode)) {
            btnModeStandard.setBackgroundColor(Color.parseColor("#1E293B"));
            btnModeIntercity.setBackgroundColor(Color.parseColor("#3B82F6"));
            btnModeDelivery.setBackgroundColor(Color.parseColor("#1E293B"));

            tilSeats.setVisibility(View.VISIBLE);
            tilPackageDetails.setVisibility(View.GONE);
            tilRecipient.setVisibility(View.GONE);

            etPickupLocation.setHint("🟢 Ciudad de Origen (ej. Felipe Carrillo Puerto)");
            etDestinationLocation.setHint("🔴 Ciudad de Destino (ej. Tulum, Chetumal, Cancún)");
            btnRequestTrip.setText("Solicitar Viaje Interurbano");
            Toast.makeText(this, "Modo: Viaje Ciudad a Ciudad seleccionado", Toast.LENGTH_SHORT).show();
        } else {
            btnModeStandard.setBackgroundColor(Color.parseColor("#3B82F6"));
            btnModeIntercity.setBackgroundColor(Color.parseColor("#1E293B"));
            btnModeDelivery.setBackgroundColor(Color.parseColor("#1E293B"));

            tilSeats.setVisibility(View.GONE);
            tilPackageDetails.setVisibility(View.GONE);
            tilRecipient.setVisibility(View.GONE);

            etPickupLocation.setHint("🟢 Punto de Recogida (¿Dónde te recogemos?)");
            etDestinationLocation.setHint("🔴 Destino (¿A dónde vas?)");
            btnRequestTrip.setText("Solicitar Viaje (Felipe Carrillo Puerto)");
            Toast.makeText(this, "Modo: Viaje Estándar seleccionado", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Obtiene la ubicación GPS en tiempo real del usuario y consulta a Google Maps Geocoding API la dirección oficial.
     */
    private void fetchRealTimeUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                double lat = location.getLatitude();
                double lng = location.getLongitude();
                userCurrentLatLng = new LatLng(lat, lng);

                // Consulta a la API oficial de Google Maps
                GoogleMapsClient.reverseGeocode(lat, lng, new GoogleMapsClient.GeocodeCallback() {
                    @Override
                    public void onSuccess(double lat, double lng, String formattedAddress) {
                        etPickupLocation.setText(formattedAddress);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        etPickupLocation.setText("Mi ubicación GPS (Felipe Carrillo Puerto)");
                    }
                });

                if (mMap != null) {
                    if (pickupMarker != null) pickupMarker.remove();

                    pickupMarker = mMap.addMarker(new MarkerOptions()
                            .position(userCurrentLatLng)
                            .title("🟢 Tu ubicación actual")
                            .snippet("Punto de recogida GPS")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));

                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userCurrentLatLng, 16f));
                }
            } else {
                userCurrentLatLng = new LatLng(19.5775, -88.0453);
                etPickupLocation.setText("Centro, Felipe Carrillo Puerto");
            }
        });
    }

    /**
     * Busca la dirección mediante la API oficial de Google Maps Geocoding.
     */
    private void searchDestinationWithGoogleMaps(String query) {
        if (mMap == null || query.isEmpty()) return;

        GoogleMapsClient.geocodeAddress(query, new GoogleMapsClient.GeocodeCallback() {
            @Override
            public void onSuccess(double lat, double lng, String formattedAddress) {
                LatLng destLatLng = new LatLng(lat, lng);

                if (destinationMarker != null) destinationMarker.remove();

                destinationMarker = mMap.addMarker(new MarkerOptions()
                        .position(destLatLng)
                        .title("🔴 Destino: " + formattedAddress)
                        .snippet("Punto de llegada de viaje / entrega")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));

                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                if (userCurrentLatLng != null) {
                    builder.include(userCurrentLatLng);
                } else {
                    builder.include(new LatLng(19.5775, -88.0453));
                }
                builder.include(destLatLng);
                mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 140));
            }

            @Override
            public void onError(String errorMessage) {
                // Si la búsqueda no retorna resultado de red, utilizar fallback local de coordenadas en Carrillo Puerto
                LatLng fallbackLatLng = getCoordinatesForLandmark(query.toLowerCase());
                if (fallbackLatLng != null && mMap != null) {
                    if (destinationMarker != null) destinationMarker.remove();
                    destinationMarker = mMap.addMarker(new MarkerOptions()
                            .position(fallbackLatLng)
                            .title("🔴 Destino: " + query)
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                }
            }
        });
    }

    private LatLng getCoordinatesForLandmark(String query) {
        if (query.contains("tecnm") || query.contains("tecnologico") || query.contains("tecnológico")) {
            return new LatLng(19.5850, -88.0410);
        } else if (query.contains("hospital")) {
            return new LatLng(19.5720, -88.0490);
        } else if (query.contains("mercado")) {
            return new LatLng(19.5760, -88.0430);
        } else if (query.contains("zapata") || query.contains("emiliano")) {
            return new LatLng(19.5830, -88.0380);
        } else if (query.contains("cbtis") || query.contains("prepa")) {
            return new LatLng(19.5810, -88.0480);
        } else if (query.contains("ado") || query.contains("terminal")) {
            return new LatLng(19.5790, -88.0440);
        } else if (query.contains("chetumal")) {
            return new LatLng(18.5141, -88.3038);
        } else if (query.contains("tulum")) {
            return new LatLng(20.2114, -87.4654);
        } else if (query.contains("playa")) {
            return new LatLng(20.6296, -87.0739);
        } else if (query.contains("cancun") || query.contains("cancún")) {
            return new LatLng(21.1619, -86.8515);
        } else {
            return new LatLng(19.5820, -88.0420);
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.clear();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            fetchRealTimeUserLocation();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);
            userCurrentLatLng = new LatLng(19.5775, -88.0453);
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userCurrentLatLng, 15f));
            etPickupLocation.setText("Centro, Felipe Carrillo Puerto");
        }

        // Selección de punto de referencia mediante la API de Google Maps al tocar la pantalla
        mMap.setOnMapClickListener(latLng -> {
            if (destinationMarker != null) destinationMarker.remove();

            destinationMarker = mMap.addMarker(new MarkerOptions()
                    .position(latLng)
                    .title("🔴 Punto de referencia seleccionado")
                    .snippet("Destino marcado en el mapa")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));

            // Geocodificación inversa oficial con la API Key de Google Maps
            GoogleMapsClient.reverseGeocode(latLng.latitude, latLng.longitude, new GoogleMapsClient.GeocodeCallback() {
                @Override
                public void onSuccess(double lat, double lng, String formattedAddress) {
                    etDestinationLocation.setText(formattedAddress);
                }

                @Override
                public void onError(String errorMessage) {
                    etDestinationLocation.setText("Ubicación marcada en el mapa");
                }
            });
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (mMap != null && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    mMap.setMyLocationEnabled(true);
                    fetchRealTimeUserLocation();
                }
            }
        }
    }
}
