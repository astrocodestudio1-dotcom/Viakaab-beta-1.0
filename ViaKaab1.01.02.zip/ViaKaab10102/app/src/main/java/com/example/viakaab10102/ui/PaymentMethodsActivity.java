package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class PaymentMethodsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_methods);

        CardView cardCash = findViewById(R.id.cardCash);
        CardView cardCreditCard = findViewById(R.id.cardCreditCard);
        CardView cardBankTransfer = findViewById(R.id.cardBankTransfer);

        cardCash.setOnClickListener(v -> 
            Toast.makeText(this, "Efectivo seleccionado como método de pago predeterminado", Toast.LENGTH_SHORT).show()
        );

        cardCreditCard.setOnClickListener(v -> 
            Toast.makeText(this, "Módulo de vinculación de tarjetas próximamente", Toast.LENGTH_SHORT).show()
        );

        cardBankTransfer.setOnClickListener(v -> 
            Toast.makeText(this, "Datos para transferencia bancaria SPEI ViaKaab", Toast.LENGTH_SHORT).show()
        );
    }
}
