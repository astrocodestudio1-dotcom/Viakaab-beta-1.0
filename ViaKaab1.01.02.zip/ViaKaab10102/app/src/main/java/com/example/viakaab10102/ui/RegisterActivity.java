package com.example.viakaab10102.ui;

import com.example.viakaab10102.MainActivity;
import com.example.viakaab10102.R;
import com.example.viakaab10102.network.SupabaseClient;
import com.example.viakaab10102.utils.SessionManager;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private EditText etName, etPhone, etAge, etEmail, etPassword;
    private TextInputLayout tilName, tilPhone, tilAge, tilEmailRegister, tilPasswordRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        sessionManager = new SessionManager(this);

        tilName = findViewById(R.id.tilName);
        tilPhone = findViewById(R.id.tilPhone);
        tilAge = findViewById(R.id.tilAge);
        tilEmailRegister = findViewById(R.id.tilEmailRegister);
        tilPasswordRegister = findViewById(R.id.tilPasswordRegister);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etAge = findViewById(R.id.etAge);
        etEmail = findViewById(R.id.etEmailRegister);
        etPassword = findViewById(R.id.etPasswordRegister);

        Button btnRegisterUser = findViewById(R.id.btnRegisterUser);
        Button btnBackToLogin = findViewById(R.id.btnBackToLogin);

        // Limpiar errores al escribir
        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) tilName.setError(null);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) tilPhone.setError(null);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        etAge.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) tilAge.setError(null);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        etEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) tilEmailRegister.setError(null);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        etPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) tilPasswordRegister.setError(null);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Al hacer clic en Registrarse
        btnRegisterUser.setOnClickListener(v -> {
            String name = etName.getText() != null ? etName.getText().toString().trim() : "";
            String phone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
            String ageStr = etAge.getText() != null ? etAge.getText().toString().trim() : "";
            String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
            String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

            boolean hasError = false;

            if (name.isEmpty()) {
                tilName.setError("Por favor ingresa tu nombre");
                hasError = true;
            } else {
                tilName.setError(null);
            }

            if (phone.isEmpty()) {
                tilPhone.setError("Por favor ingresa tu número telefónico");
                hasError = true;
            } else {
                tilPhone.setError(null);
            }

            if (ageStr.isEmpty()) {
                tilAge.setError("Por favor ingresa tu edad");
                hasError = true;
            } else {
                try {
                    Integer.parseInt(ageStr);
                    tilAge.setError(null);
                } catch (NumberFormatException e) {
                    tilAge.setError("Ingresa una edad válida");
                    hasError = true;
                }
            }

            if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmailRegister.setError("Ingresa un correo electrónico válido (ej. correo@dominio.com)");
                hasError = true;
            } else {
                tilEmailRegister.setError(null);
            }

            if (password.isEmpty() || password.length() < 6) {
                tilPasswordRegister.setError("La contraseña debe tener al menos 6 caracteres");
                hasError = true;
            } else {
                tilPasswordRegister.setError(null);
            }

            if (!hasError) {
                executeSupabaseRegistration();
            }
        });

        // Botón para volver al Login si ya tiene cuenta
        btnBackToLogin.setOnClickListener(v -> finish());
    }

    private void executeSupabaseRegistration() {
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String phone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
        String age = etAge.getText() != null ? etAge.getText().toString().trim() : "";
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        Toast.makeText(RegisterActivity.this, "Guardando usuario en Supabase...", Toast.LENGTH_SHORT).show();

        sessionManager.setUserPhone(phone);

        SupabaseClient.signUpWithRole(name, phone, age, email, password, "passenger", new SupabaseClient.AuthCallback() {
            @Override
            public void onSuccess(String responseBody) {
                // Guardar credenciales para recordar
                sessionManager.saveCredentials(email, password);
                sessionManager.createLoginSession(email, name, "passenger", "");

                new AlertDialog.Builder(RegisterActivity.this)
                        .setTitle("¡Registro Exitoso!")
                        .setMessage("Tus datos han sido guardados correctamente. A continuación, selecciona cómo deseas usar ViaKaab.")
                        .setPositiveButton("Continuar", (dialog, which) -> {
                            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                        })
                        .setCancelable(false)
                        .show();
            }

            @Override
            public void onError(String errorMessage) {
                Toast.makeText(RegisterActivity.this, "Error al guardar en base de datos: " + errorMessage, Toast.LENGTH_LONG).show();
            }
        });
    }
}
