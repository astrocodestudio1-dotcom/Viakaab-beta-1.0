package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

public class ServicesFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_services, container, false);

        CardView cardServicesTrip = view.findViewById(R.id.cardServicesTrip);
        CardView cardServicesSeniors = view.findViewById(R.id.cardServicesSeniors);
        CardView cardServicesRent = view.findViewById(R.id.cardServicesRent);
        CardView cardServicesReserve = view.findViewById(R.id.cardServicesReserve);
        CardView cardServicesFood = view.findViewById(R.id.cardServicesFood);

        View.OnClickListener openMapListener = v -> {
            Intent intent = new Intent(requireContext(), PassengerMapActivity.class);
            startActivity(intent);
        };

        cardServicesTrip.setOnClickListener(openMapListener);
        cardServicesRent.setOnClickListener(openMapListener);

        cardServicesSeniors.setOnClickListener(v -> 
            Toast.makeText(requireContext(), "Modo Personas Mayores activo", Toast.LENGTH_SHORT).show()
        );

        cardServicesReserve.setOnClickListener(v -> 
            Toast.makeText(requireContext(), "Módulo de Reserva programada", Toast.LENGTH_SHORT).show()
        );

        cardServicesFood.setOnClickListener(v -> 
            Toast.makeText(requireContext(), "Módulo ViaKaab Eats - Comida en Felipe Carrillo Puerto", Toast.LENGTH_SHORT).show()
        );

        return view;
    }
}
