package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;
import com.example.viakaab10102.utils.SessionManager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        SessionManager sessionManager = new SessionManager(this);

        // Carga rápida instantánea (500 ms)
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                Intent intent;
                if (sessionManager.isLoggedIn()) {
                    String role = sessionManager.getUserRole();
                    if ("driver".equals(role) || "delivery".equals(role) || "both".equals(role)) {
                        intent = new Intent(SplashActivity.this, DriverMapActivity.class);
                    } else {
                        // Pasajeros abren el Home Principal estilo Uber (MainContainerActivity con pestañas)
                        intent = new Intent(SplashActivity.this, MainContainerActivity.class);
                    }
                } else {
                    intent = new Intent(SplashActivity.this, LoginActivity.class);
                }
                startActivity(intent);
                finish();
            } catch (Exception e) {
                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }, 500);
    }
}
