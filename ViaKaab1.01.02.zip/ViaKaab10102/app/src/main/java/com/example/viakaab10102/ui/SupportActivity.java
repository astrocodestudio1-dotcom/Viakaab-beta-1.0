package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SupportActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        Button btnViewTerms = findViewById(R.id.btnViewTerms);
        btnViewTerms.setOnClickListener(v -> {
            Intent intent = new Intent(SupportActivity.this, TermsActivity.class);
            startActivity(intent);
        });
    }
}
