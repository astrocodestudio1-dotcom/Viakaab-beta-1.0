package com.example.viakaab10102.ui;

import com.example.viakaab10102.R;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TermsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms);

        Button btnAcceptTerms = findViewById(R.id.btnAcceptTerms);
        btnAcceptTerms.setOnClickListener(v -> finish());
    }
}
