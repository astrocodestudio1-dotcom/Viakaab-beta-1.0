package com.example.viakaab10102.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "ViaKaabSession";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_EMAIL = "userEmail";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_PHONE = "userPhone";
    private static final String KEY_PROFILE_IMAGE_URI = "profileImageUri";
    private static final String KEY_USER_ROLE = "userRole";
    private static final String KEY_ACCESS_TOKEN = "accessToken";
    private static final String KEY_SELECTED_ROLE = "selectedRole";
    private static final String KEY_HAS_SEEN_WELCOME = "hasSeenWelcome";
    private static final String KEY_SAVED_EMAIL = "savedEmail";
    private static final String KEY_SAVED_PASSWORD = "savedPassword";

    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void createLoginSession(String email, String name, String role, String token) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_ROLE, role);
        editor.putString(KEY_ACCESS_TOKEN, token);
        editor.putBoolean(KEY_HAS_SEEN_WELCOME, true);
        editor.apply();
    }

    public void saveCredentials(String email, String password) {
        editor.putString(KEY_SAVED_EMAIL, email);
        editor.putString(KEY_SAVED_PASSWORD, password);
        editor.apply();
    }

    public String getSavedEmail() {
        return prefs.getString(KEY_SAVED_EMAIL, "");
    }

    public String getSavedPassword() {
        return prefs.getString(KEY_SAVED_PASSWORD, "");
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public boolean hasSeenWelcome() {
        return prefs.getBoolean(KEY_HAS_SEEN_WELCOME, false);
    }

    public void setHasSeenWelcome(boolean seen) {
        editor.putBoolean(KEY_HAS_SEEN_WELCOME, seen);
        editor.apply();
    }

    public String getUserEmail() {
        return prefs.getString(KEY_USER_EMAIL, "");
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, "");
    }

    public void setUserName(String name) {
        editor.putString(KEY_USER_NAME, name);
        editor.apply();
    }

    public String getUserPhone() {
        return prefs.getString(KEY_USER_PHONE, "");
    }

    public void setUserPhone(String phone) {
        editor.putString(KEY_USER_PHONE, phone);
        editor.apply();
    }

    public String getProfileImageUri() {
        return prefs.getString(KEY_PROFILE_IMAGE_URI, "");
    }

    public void setProfileImageUri(String uri) {
        editor.putString(KEY_PROFILE_IMAGE_URI, uri);
        editor.apply();
    }

    public String getUserRole() {
        return prefs.getString(KEY_USER_ROLE, "passenger");
    }

    public String getAccessToken() {
        return prefs.getString(KEY_ACCESS_TOKEN, "");
    }

    public void setSelectedRole(String role) {
        editor.putString(KEY_SELECTED_ROLE, role);
        editor.apply();
    }

    public String getSelectedRole() {
        return prefs.getString(KEY_SELECTED_ROLE, "passenger");
    }

    public void logout() {
        String savedEmail = getSavedEmail();
        String savedPassword = getSavedPassword();

        editor.clear();
        editor.putBoolean(KEY_IS_LOGGED_IN, false);
        editor.putBoolean(KEY_HAS_SEEN_WELCOME, true);
        editor.putString(KEY_SAVED_EMAIL, savedEmail);
        editor.putString(KEY_SAVED_PASSWORD, savedPassword);
        editor.apply();
    }
}
